// js/register.js — จัดการฟอร์มสมัครสมาชิก (localStorage demo)
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("registerForm");
  const errorBox = document.getElementById("errorBox");
  const successBox = document.getElementById("successBox");

  if (ctGetSession()) { window.location.href = "dashboard.html"; return; }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    errorBox.classList.remove("show");
    successBox.classList.remove("show");

    const fullName = form.full_name.value.trim();
    const username = form.username.value.trim();
    const email = form.email.value.trim();
    const password = form.password.value;
    const confirm = form.confirm_password.value;

    const errors = [];
    if (!fullName || !username || !email || !password) errors.push("กรุณากรอกข้อมูลให้ครบทุกช่อง");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push("รูปแบบอีเมลไม่ถูกต้อง");
    if (!/^[a-zA-Z0-9_]{3,50}$/.test(username)) errors.push("ชื่อผู้ใช้ต้องเป็นภาษาอังกฤษ ตัวเลข หรือ _ เท่านั้น (3-50 ตัวอักษร)");
    if (password.length < 6) errors.push("รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร");
    if (password !== confirm) errors.push("รหัสผ่านและการยืนยันรหัสผ่านไม่ตรงกัน");

    const users = ctGetUsers();
    if (users.some(u => u.username === username || u.email === email)) {
      errors.push("ชื่อผู้ใช้หรืออีเมลนี้ถูกใช้งานแล้ว");
    }

    if (errors.length) {
      errorBox.innerHTML = errors.map(e => `<div>${e}</div>`).join("");
      errorBox.classList.add("show");
      return;
    }

    users.push({ fullName, username, email, password }); // เดโม: เก็บใน localStorage เท่านั้น ไม่เข้ารหัส
    ctSaveUsers(users);

    successBox.textContent = "สมัครสมาชิกสำเร็จ! กำลังพาไปหน้าเข้าสู่ระบบ...";
    successBox.classList.add("show");
    form.reset();
    setTimeout(() => window.location.href = "login.html", 1200);
  });
});
