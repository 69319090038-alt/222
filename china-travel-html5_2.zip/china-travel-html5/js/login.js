// js/login.js — จัดการฟอร์มเข้าสู่ระบบ (localStorage demo)
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("loginForm");
  const errorBox = document.getElementById("errorBox");

  if (ctGetSession()) { window.location.href = "dashboard.html"; return; }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    errorBox.classList.remove("show");

    const identity = form.identity.value.trim();
    const password = form.password.value;

    const users = ctGetUsers();
    const user = users.find(u => (u.username === identity || u.email === identity) && u.password === password);

    if (!user) {
      errorBox.textContent = "ชื่อผู้ใช้/อีเมล หรือรหัสผ่านไม่ถูกต้อง";
      errorBox.classList.add("show");
      return;
    }

    ctSetSession(user);
    window.location.href = "dashboard.html";
  });
});
