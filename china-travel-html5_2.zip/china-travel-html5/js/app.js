// ==========================================================
// js/app.js — พฤติกรรมร่วมของทุกหน้า (นำทาง, filter, reveal, auth state)
// ระบบสมาชิกในไฟล์นี้เป็น "ฝั่ง client เท่านั้น" เก็บด้วย localStorage
// เพื่อจำลองการสมัคร/เข้าสู่ระบบสำหรับเดโม ไม่เหมาะกับใช้งานจริง
// (ใช้งานจริงควรมี backend + ฐานข้อมูล + เข้ารหัสรหัสผ่านฝั่งเซิร์ฟเวอร์)
// ==========================================================

const CT_USERS_KEY = "ctUsers";
const CT_SESSION_KEY = "ctSession";

function ctGetUsers() {
  return JSON.parse(localStorage.getItem(CT_USERS_KEY) || "[]");
}
function ctSaveUsers(users) {
  localStorage.setItem(CT_USERS_KEY, JSON.stringify(users));
}
function ctGetSession() {
  return JSON.parse(localStorage.getItem(CT_SESSION_KEY) || "null");
}
function ctSetSession(user) {
  localStorage.setItem(CT_SESSION_KEY, JSON.stringify({ username: user.username, fullName: user.fullName }));
}
function ctLogout() {
  localStorage.removeItem(CT_SESSION_KEY);
  window.location.href = "index.html";
}

// ----- แสดงสถานะสมาชิกในเมนูด้านบนของทุกหน้า -----
function ctRenderAuthNav() {
  const box = document.getElementById("navAuth");
  if (!box) return;
  const session = ctGetSession();
  if (session) {
    box.innerHTML = `
      <span style="font-size:.86rem; color:var(--ink-soft);">สวัสดี, ${session.fullName}</span>
      <a href="dashboard.html" class="btn btn-ghost">บัญชีของฉัน</a>
      <a href="#" id="logoutBtn" class="btn btn-ghost">ออกจากระบบ</a>
    `;
    document.getElementById("logoutBtn").addEventListener("click", (e) => {
      e.preventDefault();
      ctLogout();
    });
  } else {
    box.innerHTML = `
      <a href="login.html" class="btn btn-ghost">เข้าสู่ระบบ</a>
      <a href="register.html" class="btn btn-primary">สมัครสมาชิก</a>
    `;
  }
}

// ----- ป้องกันหน้าสมาชิก (dashboard.html) -----
function ctRequireLogin() {
  if (!ctGetSession()) {
    window.location.href = "login.html";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  ctRenderAuthNav();

  // มือถือ: เปิด/ปิดเมนู
  const toggle = document.getElementById("navToggle");
  const links = document.getElementById("navLinks");
  if (toggle && links) {
    toggle.addEventListener("click", () => links.classList.toggle("open"));
  }

  // เอฟเฟกต์ reveal-on-scroll สำหรับการ์ด
  const revealTargets = document.querySelectorAll(".card, .fact-list li");
  if ("IntersectionObserver" in window && revealTargets.length) {
    revealTargets.forEach(el => {
      el.style.opacity = 0;
      el.style.transform = "translateY(14px)";
      el.style.transition = "opacity .5s ease, transform .5s ease";
    });
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = 1;
          entry.target.style.transform = "translateY(0)";
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealTargets.forEach(el => io.observe(el));
  }

  // ปุ่มกรองหมวดหมู่ (ใช้ในหน้า destinations / photo-spots / souvenirs)
  const filterButtons = document.querySelectorAll("[data-filter]");
  const cards = document.querySelectorAll("[data-category]");
  if (filterButtons.length && cards.length) {
    filterButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        filterButtons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        const filter = btn.getAttribute("data-filter");
        cards.forEach(card => {
          const show = filter === "all" || card.getAttribute("data-category") === filter;
          card.style.display = show ? "" : "none";
        });
      });
    });
  }
});
